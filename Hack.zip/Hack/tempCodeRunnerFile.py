category = None
    if request.method == 'POST':
        text = request.form['text']
        text=Cleaning(text)
        
        models=load_model(r'C:\Users\HP\Desktop\Kaviya\Hack\Email_Classification_LSTM_1.hdf5')
        y_pred=models.predict(text)

        print("hello",y_pred)
        predicted_classes = np.argmax(y_pred, axis=1)

        print("output",predicted_classes)
